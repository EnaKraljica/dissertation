<?php
    require "database-config.php";

    if(isset($_POST["submit"]))
    {
        //Taking the user input.
        $name = $_POST["name"];
        $username = $_POST["username"];
        $email = $_POST["email"];
        $cv = $_POST["cv"];
        $track = $_POST["track"];
        $graduating = $_POST["graduationyear"];
        $about = $_POST["description"];
        $password = $_POST["password"];
        $pwdretype = $_POST["password-confirm"];
        $defaultPic = "images/default_profile.png";
        // All the necessary checks and error handling
        // is done inside this function which makes use of 
        // other functions implemented inside "functions.php".

        if($password == $pwdretype)
        {
            $sql = "INSERT INTO user_account(name, username, password, user_image)
            VALUES('$name', '$username', '$password');";
            $sql .= "INSERT INTO cv(file)
            VALUES('$cv');";
            $sql .= "INSERT INTO student(graduation_yr, description)
            VALUES('$graduating', '$about');";

            if ($conn->multi_query($sql) === TRUE)
            {
                echo "Profile successfully updated!";
                header("location: login.php");
            }
            else
                echo "Error: <br>" . $conn->error;
        }
        else
            echo "Passwords don't match";
    }
    else
        header("location: userprofile.php");
?>