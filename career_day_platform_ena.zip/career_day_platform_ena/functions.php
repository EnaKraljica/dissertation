<?php 
    //require "database-config.php";

    function login($conn, $username, $password){

        $sql = "SELECT id FROM user_account WHERE $username = '$username' AND password = '$password'";

        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
        $count = mysqli_num_rows($result);

        if($count == 1){
            session_start();
            //session_register("id");
            $_SESSION['id'] = $row["id"];
            
            header("location: home-one.php");
        }
        else{
            echo "Incorrect username or password";
        }
    }

    function upload_cv($conn, $studentid, $cvfile){

            if(is_null($cvfile)){
                echo "File is empty";
                return;
            }

            $sql = "INSERT INTO cv (student_id, file)
                VALUES ('$studentid', '$cvfile')";

            if ($conn->query($sql) === TRUE) {
                echo "CV successfully uploaded!";
            } else {
                echo "Error: <br>" . $conn->error;
            }
    }

    function create_job($conn, $userid, $role, $qualifications, $companyid, $description, $location){

        if(is_null($role) || is_null($qualifications) || is_null($companyid) || is_null($description) || is_null($location)){
            echo "Please insert all data";
            return;
        }

        $sql = "INSERT INTO job_post (posted_by_id, role, min_qualifications, company_id, job_desc, job_location_id)
                VALUES ('$userid', '$role', '$qualifications', '$companyid', '$description', '$location')";

            if ($conn->query($sql) === TRUE) {
                echo "Job posted successfully!";
            } else {
                echo "Error: <br>" . $conn->error;
            }

    }


?>