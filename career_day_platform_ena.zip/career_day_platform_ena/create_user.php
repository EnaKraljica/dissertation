<?php
    require "database-config.php";

    if(isset($_POST["submit"]))
    {

        //Taking the user input.
        $name = $_POST["name"];
        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        $pwdretype = $_POST["password-confirm"];
        $defaultPic = "images/default_profile.png";
        // All the necessary checks and error handling
        // is done inside this function which makes use of 
        // other functions implemented inside "functions.php".

        if($password == $pwdretype)
        {

            $name = $fname . " " . $lname;

            $sql = "INSERT INTO user_account (name, username, password, user_image)
                VALUES ('$name', '$email', '$password', '$defaultPic')";

            if ($conn->query($sql) === TRUE)
            {
                echo "User successfully registered!";
                header("location: login.php");
            }
            else
                echo "Error: <br>" . $conn->error;
        }
        else
            echo "Passwords don't match";
    }
    else
        header("location: register.php");
?>