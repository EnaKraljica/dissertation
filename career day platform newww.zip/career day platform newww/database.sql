DROP TABLE user_account CASCADE CONSTRAINTS;
CREATE TABLE user_account (
    `id` int(11),
    `user_type` varchar(20),
    `name` varchar(30),
    `username` varchar(30),
    `password` varchar(30),
    `registration_date` date,
    `address` varchar2(50),
    `user_image` varbinary(max)
); 

DROP TABLE company CASCADE CONSTRAINTS;
CREATE TABLE company(
    `id` int(11),
    `profile_desc` varchar(250),
    -- it, business,psychology
    `company_stream` varchar(50),
    `company_website` varchar(3000)
);

DROP TABLE company_image CASCADE CONSTRAINTS;
CREATE TABLE company_image(
    `id` int(11),
    `company_id` int(11),
    `company_image` varbinary(max)
);

DROP TABLE business_stream CASCADE CONSTRAINTS;
CREATE TABLE business_stream(
    `id` int(11),
    `business_stream_name` varchar(50)
);


DROP TABLE student CASCADE CONSTRAINTS;
CREATE TABLE student(
    `user_acc_id` int(11),
    `fname` varchar(15),
    `lname` varchar(30),
    `sex` char,
    `field_of_study` varchar(30),
    `graduation_yr` int(4),
    `description` varchar(200),
    foreign key (user_acc_id) references user_account(id);
    primary key (user_acc_id);
    
);

DROP TABLE field_of_study CASCADE CONSTRAINTS;
CREATE TABLE field_of_study(
    `id` int(11),
    `field_of_study_name` varchar(50)
);

DROP TABLE job_post CASCADE CONSTRAINTS;
CREATE TABLE job_post(
    `id` int(11),
    `posted_by_id` int(11),
    `role` varchar(30),
    `min_qualifications` varchar(30),
    `company_id` int(30),
    `job_desc` varchar(200),
    `job_location_id` int(11),
    `date_posted` int(15)
    
);

DROP TABLE job_post CASCADE CONSTRAINTS;
CREATE TABLE job_location(
    `id` int(11),
    `street_address` varchar(30),
    `city` varchar(30),
    `country`varchar(30)
);

DROP TABLE job_type CASCADE CONSTRAINTS;
CREATE TABLE job_type(
    `id` int(11),
    `job_type` varchar(30)
);

DROP TABLE director CASCADE CONSTRAINTS;
CREATE TABLE director(
    `user_acc_id` int(11)

);

DROP TABLE cv CASCADE CONSTRAINTS;
CREATE TABLE cv(

    `student_id` varchar(30),
    `file` varbinary(max)
    
);

DROP TABLE cv_job_post CASCADE CONSTRAINTS;
CREATE TABLE cv_job_post(
    `stundet_id` varchar(30),
    `job_post_id` varchar(30)
);


