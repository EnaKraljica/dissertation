<!DOCTYPE html>
<html lang="en">
<?php
     require "header.php"; 
    ?>
<head>

     <title>Career Day Platform</title>

     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/owl.carousel.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="css/style.css">

</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">
               <span class="spinner-rotate"></span>
          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <a href="#" class="navbar-brand">CAREER DAY PLATFORM</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-nav-first">
                         <li class="active"><a href="index.html">Home</a></li>
                         <li><a href="job-listing.html">Jobs</a></li>
                         <li><a href="blog-posts.html">Career Advice</a></li>
                         <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Sign Up<span class="caret"></span></a>
                              
                              <ul class="dropdown-menu">
                                   <li ><a href="login-page.html">Log In</a></li>
                                   <li><a href="register.html">Register</a></li>
                              </ul>
                         </li>
                         <li><a href="contact.html">Contact Us</a></li>
                    </ul>
               </div>

          </div>
     </section>


     <!-- CONTACT -->
     <section id="contact">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <div class="section-title">
                                   <h2>Login to Your Account</h2>
                              </div>
                              <form id="contact-form" role="form" action="" method="post">
                              <div class="col-md-12 col-sm-12">
                    
                                   <input type="email" class="form-control" placeholder="Enter email address" name="email" required>
                                   <input type="password" class="form-control" placeholder="Enter password" name="password" required>


                              </div>

                              <div class="col-md-4 col-sm-12">
                                   <input type="submit" class="form-control" name="login" value="Log in">
                              </div>

                         </form> 
                         <?php

    if(isset($_GET["error"])){
       if($_GET["error"]=="wrongcredentials"){
            echo"<p>Login failed. <br> Please check if you filled your information correctly.</p>";
        }else if($_GET["error"]=="userstmtfailed"){
            echo"<p style='color:red;'>There was an error.<br> Please try again.</p>";
        }else if($_GET["error"]=="inputempty"){
            echo"<p style='color:red;'>You need to fill in all the fields!</p>";
        }else if($_GET["error"] == "invalidemail"){
            echo"<p style='color:red;'>Please enter a valid email.</p>";
        }
    }


   
?>          
                         </div>
                    </div>

               </div>
          </div>
     </section>       


    <!-- FOOTER -->
     <footer id="footer">
          <div class="container">
               <div class="row">

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>Campus</h2>
                              </div>
                              <address>
                                   <p>LAtomiou 7 <br>Thessaloniki, Greece</p>
                              </address>

                              <ul class="social-icon">
                                   <li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                   <li><a href="#" class="fa fa-twitter"></a></li>
                                   <li><a href="#" class="fa fa-instagram"></a></li>
                              </ul>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2>Contact Us</h2>
                              </div>
                              <address>
                                   <p>+30 698 73 5566</p>
                                   <p><a href="mailto:contact@company.com">career@york.com</a></p>
                              </address>

                              <div class="footer_menu">
                                   <h2>Quick Links</h2>
                                   <ul>
                                        <li><a href="index.html">Home</a></li>
                                        <li><a href="about-us.html">About Us</a></li>
                                        <li><a href="terms.html">Career Advice</a></li>
                                        <li><a href="contact.html">Contact Us</a></li>
                                   </ul>
                              </div>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-12">
                         <div class="footer-info newsletter-form">
                              <div class="section-title">
                                   <h2>Newsletter Signup</h2>
                              </div>
                              <div>
                                   <div class="form-group">
                                        <form action="#" method="get">
                                             <input type="email" class="form-control" placeholder="Enter your email" name="email" id="email" required>
                                             <input type="submit" class="form-control" name="submit" id="form-submit" value="Send me">
                                        </form>
                                        <span><sup>*</sup> Sign up and get notified about new jobs!</span>
                                   </div>
                              </div>
                         </div>
                    </div>
                    
               </div>
          </div>
     </footer>


     <!-- SCRIPTS -->
     <script src="js/jquery.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script src="js/owl.carousel.min.js"></script>
     <script src="js/smoothscroll.js"></script>
     <script src="js/custom.js"></script>

</body>
</html>