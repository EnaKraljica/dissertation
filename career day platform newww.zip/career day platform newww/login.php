<?php
    require "database-config.php";
    require "functions.php";
   
// Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

?>
<?php
    if(isset($_POST["submit"])){
        $email = $_POST["email"];
        $password = $_POST["pass"];

        loginUser($conn,$email,$password);
    }else{
        header("location:login.php");
        exit();
    }

?>